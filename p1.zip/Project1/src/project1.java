import java.io.File;
import java.util.LinkedList;
import java.util.Map;
import java.util.Queue;
import java.util.Scanner;

public class project1 {
	static int xs = 0;
	static int ys = 0;
	static int xf = 0;
	static int yf = 0;
	static int a;
	static int b;
	static int c;
	static Queue<Integer> xq = new LinkedList<Integer>();
	static Queue<Integer> yq = new LinkedList<Integer>();
	static int[][] map;
	
	public static void pushDP(int x, int y) {
		if(map[y][x] == -3) {
			System.out.println("FOUND");
			xq.clear();
			yq.clear();
			for(int i = 0; i < a; i++) {
				for(int j = 0; j < b; j++) {
					System.out.print(map[i][j] + " ");
				}
				System.out.println("");
			}
		} else {
			// push up
			if(y+1 < map[0].length) {
				if(map[x][y+1] > map[x][y]+1 && map[x][y+1] > 0) {
					map[x][y+1] = map[x][y]+1;
					xq.add(x);
					yq.add(y+1);
					
				}
			}
			
			if(x+1 < map.length) {
				if(map[x+1][y] > map[x][y]+1 && map[x+1][y] > 0) {
					map[x+1][y] = map[x][y]+1;
					xq.add(x+1);
					yq.add(y);
					
				}
			}
			
			if(x > 0) {
				if(map[x-1][y] > map[x][y]+1 && map[x-1][y] > 0) {
					map[x-1][y] = map[x][y]+1;
					xq.add(x-1);
					yq.add(y);
				}
			}
			
			if(y > 0) {
				if(map[x][y-1] > map[x][y]+1 && map[x][y-1] > 0) {
					map[x][y-1] = map[x][y]+1;
					xq.add(x);
					yq.add(y-1);
				}
			}
		}
		
		System.out.println(x + ":" + y);	
	}

	public static void project1(File f) {
		

		map = new int[1000][1000];
		boolean coordbased = false;

		if(coordbased == true ) {
			
			try {
				Scanner input = new Scanner(f);
				
				a = input.nextInt();
				
				b = input.nextInt();
				
				c = input.nextInt();
				
				for(int i = 0; i < a; i++) {
					for(int j = 0; j < b; j++) {
						map[i][j] = 1000;
					}
				}
				while(input.hasNextLine()) {
					String line = input.nextLine();
					int i = (int) line.charAt(2); 
					int j = (int) line.charAt(4);
					char x = line.charAt(0);
					
					
				}
				
			} catch(Exception e) {
				System.out.println("EXCEPTION");
			}

			
		} else {
		
			try {
				
				Scanner input = new Scanner(f);
				
				a = input.nextInt();
				
				b = input.nextInt();
				
				c = input.nextInt();


				// initialize array

				for(int i = 0; i < a; i++) {
					String v = input.next();
					for(int j = 0; j < b; j++) {
						char l = v.charAt(j);
						int z = 0;
						if(v.charAt(j) == 'C') {
							yf = i;
						
							xf = j;
							z=-3;
						}
						if(v.charAt(j) == 'K') {
							ys = i;
							xs = j;
							z=0;
						}

						if(v.charAt(j) == '.') {
							z = 1000;
						}
						if(v.charAt(j) == '@') {
							z = -1;
						}
						map[i][j] = z;
					}
				}
				
				xq.add(xs);
				yq.add(ys);
				while(xq.size() != 0) {
					pushDP(xq.remove(), yq.remove());
				}
				
				
				
			} catch(Exception e) {
				
				System.out.println(e);
				System.exit(1);
			}
			
		}		
		
	}

	public static void main(String args[]) {

//		File f = new File("./");
//        String [] pathnames = f.list();
//        for (String pathname : pathnames) {
//            System.out.println(pathname);
//        }

		File x = new File("./src/map.txt");

		project1(x);
	}

}
