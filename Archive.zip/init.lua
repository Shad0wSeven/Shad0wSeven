-------------
-- IMPORTS --
-------------
require "paq" {
	"tweekmonster/startuptime.vim";
	"savq/paq-nvim";                  -- Let Paq manage itself
	"nvim-treesitter/nvim-treesitter";
	"Aryansh-S/fastdark.vim";
	"drewtempelmeyer/palenight.vim";
	"neovim/nvim-lspconfig";
	"hrsh7th/nvim-compe";
	"tpope/vim-fugitive";
	"tpope/vim-surround";
	"kaicataldo/material.vim";
	"junegunn/goyo.vim";
	"junegunn/fzf";
	"junegun/fzf.vim";
	"mhinz/vim-startify";
	"hoob3rt/lualine.nvim";	
	"kyazdani42/nvim-web-devicons";
	"onsails/lspkind-nvim";
	"folke/zen-mode.nvim";
	"lukas-reineke/indent-blankline.nvim";
	"folke/tokyonight.nvim";
	"nvim-lua/popup.nvim";
	"nvim-lua/plenary.nvim";
	"nvim-telescope/telescope.nvim";
	"preservim/nerdcommenter";
	"jiangmiao/auto-pairs";
	"SirVer/ultisnips";
	"honza/vim-snippets";
	"searleser97/cpbooster.vim";
}

------------------------
-- IMPORT OTHER FILES --
------------------------
require('lineconfig')
require('treesitterconfig')
require('compeconfig')


------------
-- RANDOM --
------------
require("zen-mode").setup {
    -- your configuration comes here
    -- or leave it empty to use the default settings
    -- refer to the configuration section below
}



require'nvim-web-devicons'.setup {
 -- your personnal icons can go here (to override)
 -- DevIcon will be appended to `name`
 -- globally enable default icons (default to false)
 -- will get overriden by `get_icons` option
 default = true;
}

--------------------
-- VIM MODE STUFF --
--------------------
-- TBH this could have been a .vim file. . .

vim.cmd [[
	
	" " NERDCommenter
		" " Use compact syntax for prettified multi-line comments
		let g:NERDCompactSexyComs = 1
		" " Allow commenting and inverting empty lines (useful when commenting a region)
		let g:NERDCommentEmptyLines = 1
		" " Enable trimming of trailing whitespace when uncommenting
		let g:NERDTrimTrailingWhitespace = 1
		" " Enable NERDCommenterToggle to check all selected lines is commented or not
		let g:NERDToggleCheckAllLines = 1
		" " Add spaces after comment delimiters by default
		let g:NERDSpaceDelims = 1
		" " Map ++ to call NERD Commenter and use iTerm key bindings 
		" " to bind Ctmd+/ to ++
		vmap ++ <plug>NERDCommenterToggle
		nmap ++ <plug>NERDCommenterToggle
		
		
	" " UltiSnippet Directories
		let g:UltiSnipsSnippetDirectories=[$HOME.'/.config/nvim/UltiSnips']
		let g:completion_enable_snippet = 'UltiSnips'


	" " Remap Custom Header
		nnoremap ff :Telescope find_files<CR>


	" " Ascii Art for Starter
		let g:startify_custom_header = [',~~_','|/\ =_ _ ~',' _( )_( )\~~',' \,\  _|\ \~~~','    \`   \','    `    `']
		:autocmd BufNewFile *.cpp 0r ~/.vim/templates/skeleton.cpp


	" " Custom Indent line
		let g:indentLine_char = '┆'


	" " General Stuff
		set tabstop=4
		set shiftwidth=4
		set noshowmode
		set relativenumber
		set noswapfile
		set completeopt=menuone,noselect
		colo tokyonight
		map <ScrollWheelDown> j
		map <ScrollWheelUp> k


	" " Completion Stuff
		inoremap <silent><expr> <TAB> pumvisible() ? "\<C-n>" : "\<TAB>"
		inoremap <expr><S-TAB> pumvisible() ? "\<C-p>" : "\<C-h>"


set mouse=a

]]
