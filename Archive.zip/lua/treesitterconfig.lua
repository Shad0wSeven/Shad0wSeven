---------------------
-- NVIM TREESITTER --
---------------------
require'nvim-treesitter.configs'.setup {
    highlight = {
      enable = true,
      custom_captures = {
      },
    },
  }
  
  
  local lsp_servers = {"clangd", "pyright"}
  for _, server in ipairs(lsp_servers) do
      require('lspconfig')[server].setup {
      }
  end 
  
  require('lspkind').init({
      -- enables text annotations
      with_text = true,
  
      -- default symbol map
      -- can be either 'default' or
      -- 'codicons' for codicon preset (requires vscode-codicons font installed)
      preset = 'codicons',
  
      -- override preset symbols
      symbol_map = {
        Text = '',
        Method = 'ƒ',
        Function = '',
        Constructor = '',
        Variable = '',
        Class = '',
        Interface = 'ﰮ',
        Module = '',
        Property = '',
        Unit = '',
        Value = '',
        Enum = '了',
        Keyword = '',
        Snippet = '﬌',
        Color = '',
        File = '',
        Folder = '',
        EnumMember = '',
        Constant = '',
        Struct = ''
      },
  })